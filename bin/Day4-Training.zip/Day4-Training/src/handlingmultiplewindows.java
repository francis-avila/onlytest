import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.Iterator;
import java.util.Set;

public class handlingmultiplewindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.gecko.driver", "c:\\work\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("https://accounts.google.com/signup");
		//driver.findElement(By.xpath("//html/body/div[1]/div[1]/footer/ul/li[1]/a")).click();
		
		Actions oAct = new Actions(driver);
		
		oAct.moveToElement(driver.findElement(By.xpath("//html/body/div[1]/div[1]/footer/ul/li[1]/a"))).contextClick().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
		
		//System.out.println(driver.getTitle());
		
		Set<String> ids=driver.getWindowHandles();
		Iterator<String> its=ids.iterator();
		//String parent=its.next();
		//String child=its.next();
		//driver.switchTo().window(child);
		//System.out.println(driver.getTitle());
		while(its.hasNext()) {
			driver.switchTo().window(its.next());
			System.out.println(driver.getTitle());
		}
	}

}
